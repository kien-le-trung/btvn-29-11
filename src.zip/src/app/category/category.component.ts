import {Component} from '@angular/core';

@Component({
    selector: 'category',
    templateUrl: './category.component.html',
})

export class CategoryComponent{
    displayIndicatorValue: boolean = false;
    dropIndicatorValue: boolean = false;
}