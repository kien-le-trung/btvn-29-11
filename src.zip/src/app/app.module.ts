import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CategoryComponent } from './category/category.component';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { AppFooterComponent } from './shared/appfooter/appfooter.component';
import { AppHeaderComponent } from './shared/appheader/appheader.component';
import { AppHeroComponent } from './shared/apphero/apphero.component';

const apps: Routes = [
  {path:'home', component:HomeComponent},
  {path:'category', component:CategoryComponent},
  {path:'product', component:ProductComponent}
]

@NgModule({
  declarations: [
    AppComponent, ProductComponent, CategoryComponent, HomeComponent,
    AppHeaderComponent, AppHeroComponent, AppFooterComponent 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(apps)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
