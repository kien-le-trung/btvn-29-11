import {Component} from "@angular/core";

@Component({
    selector: 'product',
    templateUrl: './product.component.html'
})

export class ProductComponent{

    dropIndicatorvalue1: boolean = false;
    displayIndicatorvalue1: boolean = false;
    initialValue: number = 1;

    defaultImage: any = "../../assets/img/product/details/product-details-1.jpg";
    image1: any = "../../assets/img/product/details/thumb-1.jpg";
    image2: any = "../../assets/img/product/details/thumb-2.jpg";
    image3: any = "../../assets/img/product/details/thumb-3.jpg";
    image4: any = "../../assets/img/product/details/thumb-4.jpg";


    increment(){
        this.initialValue++;
    }

    decrement(){
        this.initialValue--;
        while(this.initialValue<0){
            alert("You cannot select fewer than 0 items");
            this.initialValue++
        }
    }

    display1(){
        this.defaultImage = this.image1
    }

    display2(){
        this.defaultImage = this.image2
    }

    display3(){
        this.defaultImage = this.image3
    }

    display4(){
        this.defaultImage = this.image4
    }
}