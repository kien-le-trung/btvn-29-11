import { Component, Input, OnInit } from "@angular/core";

@Component ({
    selector: 'app-hero',
    templateUrl: './apphero.component.html'
})

export class AppHeroComponent{

    @Input() displayIndicator: boolean;

    @Input() dropIndicator: boolean;

    barClick(){
        switch(this.dropIndicator){
            case true:
                this.dropIndicator = false
                break;
            case false:
                this.dropIndicator = true;
                break;
        }
    }
}