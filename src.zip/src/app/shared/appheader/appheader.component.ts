import { Component } from "@angular/core";

@Component ({
    selector: 'app-header',
    templateUrl: './appheader.component.html'
})

export class AppHeaderComponent{
    
    active1 = 'active'
    active2 = 'disabled'
    active3 = 'disabled'

    pageSwitch1(){
        this.active1 = 'active'
        this.active2 = 'disabled'
        this.active3 = 'disabled'
    }

    pageSwitch2(){
        this.active1 = 'disabled'
        this.active2 = 'active'
        this.active3 = 'disabled'
    }

    pageSwitch3(){
        this.active1 = 'disabled'
        this.active2 = 'disabled'
        this.active3 = 'active'
    }

}