import { Component } from "@angular/core";

@Component({
    selector: 'app-footer',
    templateUrl: './appfooter.component.html'
})

export class AppFooterComponent{

    year = new Date().getFullYear()

}